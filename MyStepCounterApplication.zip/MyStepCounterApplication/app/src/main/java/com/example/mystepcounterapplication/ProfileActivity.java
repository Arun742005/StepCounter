package com.example.mystepcounterapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ProfileActivity extends AppCompatActivity {

    private TextView historyTextView, progressTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Find the Toolbar in the layout
        Toolbar toolbar = findViewById(R.id.toolbar);  // The Toolbar ID should match what you have in XML
        setSupportActionBar(toolbar);  // Set the toolbar as the ActionBar

        // Enable the back arrow on the ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);  // This enables the back arrow
            getSupportActionBar().setDisplayShowHomeEnabled(true);  // Ensure the back arrow is visible
        }

        // Initialize TextViews
        historyTextView = findViewById(R.id.historyTextView);
        progressTextView = findViewById(R.id.progressTextView);

        // Retrieve step count history from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("StepCounterPrefs", MODE_PRIVATE);
        int lastStepCount = sharedPreferences.getInt("lastStepCount", 0);
        int stepGoal = sharedPreferences.getInt("stepGoal", 10000);

        int progress = (int) (((float) lastStepCount / stepGoal) * 100);

        historyTextView.setText("Last Step Count: " + lastStepCount);
        progressTextView.setText("Progress: " + progress + "%");
    }

    // Handle back navigation when the back arrow is pressed
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();  // Navigate back to MainActivity
        return true;
    }
}
