package com.example.mystepcounterapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private TextView stepCountTextView, goalTextView, caloriesTextView, distanceTextView;
    private ProgressBar progressBar;
    private int stepCount = 0;
    private int stepGoal = 10000;  // Default goal: 10,000 steps
    private float weight = 70; // Default weight in kg (modifiable)
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

        if (!isLoggedIn) {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        }

        // Initialize UI components
        stepCountTextView = findViewById(R.id.stepCountTextView);
        goalTextView = findViewById(R.id.goalTextView);
        caloriesTextView = findViewById(R.id.caloriesTextView);
        distanceTextView = findViewById(R.id.distanceTextView);
        progressBar = findViewById(R.id.progressBar);
        ImageView profileIcon = findViewById(R.id.profileIcon);

        sharedPreferences = getSharedPreferences("StepCounterPrefs", MODE_PRIVATE);
        stepGoal = sharedPreferences.getInt("stepGoal", 10000);
        goalTextView.setText("Goal: " + stepGoal + " steps");

        // Handle Profile Icon Click
        profileIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ProfileActivity.class));
            }
        });

        // Initialize sensor manager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stepCounterSensor != null) {
            sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            stepCount = (int) event.values[0];
            stepCountTextView.setText("Step Count: " + stepCount);

            // Save step count
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("lastStepCount", stepCount);
            editor.apply();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not required for step counting
    }
}
